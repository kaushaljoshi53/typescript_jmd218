// @ts-nocheck
var taskInput = document.getElementById('taskInput');
var addButton = document.getElementById('addTaskButton');
var taskTable = document.getElementById('taskList');
var searchInput = document.getElementById('searchInput');
// const searchBtn = document.getElementById('searchBtn') as HTMLButtonElement;
var datalist = document.getElementById('taskSuggestion');
var tasks = [];
function addTask() {
    var taskName = taskInput.value.trim();
    if (taskName != '') {
        var exists = tasks.find(function (ts) { return ts === taskName; });
        if (exists) {
            alert('Task already exists');
        }
        else {
            var tableRow = document.createElement('tr');
            tableRow.id = taskName;
            tableRow.innerHTML = "<td>\n        <input type=\"checkbox\" aria-label=\"checkbox\" class=\"task-checkbox\">\n    </td>\n    <td>\n        <span class=\"task-name\">".concat(taskName, "</span>\n    </td>\n    <td>\n        <select class=\"task-status\">\n            <option value=\"to-do\">To Do</option>\n            <option value=\"in-progress\">In Progress</option>\n            <option value=\"completed\">Completed</option>\n        </select>\n    </td>\n    <td>\n        <button class=\"delete-button\" onclick=\"deleteRow(this)\">X</button>\n    </td>");
            taskTable.appendChild(tableRow);
            taskInput.value = '';
            tasks.push(taskName);
            updateTaskSuggestions(); // Call this to update suggestions
        }
    }
}
addButton.addEventListener('click', function () {
    addTask();
});
taskInput.addEventListener('keydown', function (event) {
    if (event.key === 'Enter') {
        addTask();
    }
});
function deleteRow(delbtn) {
    var _a;
    row = (_a = delbtn.parentElement) === null || _a === void 0 ? void 0 : _a.parentElement;
    ind = tasks.findIndex(function (t) { return t === row.id; });
    if (ind != -1) {
        tasks.splice(ind, 1);
    }
    row.remove();
}
var reset;
taskTable.addEventListener('change', function (event) {
    var _a, _b;
    var target = event.target;
    if (target.classList.contains('task-checkbox')) {
        var checkbox = target;
        var row = (_a = target.parentElement) === null || _a === void 0 ? void 0 : _a.parentElement;
        var taskstatus = row.querySelector('.task-status');
        var name_1 = row.querySelector('.task-name');
        if (checkbox.checked) {
            reset = taskstatus.value;
            taskstatus.value = 'completed';
            name_1.style.textDecoration = 'line-through';
        }
        else {
            taskstatus.value = reset;
            name_1.style.textDecoration = 'none';
        }
    }
    if (target.classList.contains('task-status')) {
        var status_1 = target;
        var row = (_b = target.parentElement) === null || _b === void 0 ? void 0 : _b.parentElement;
        var checkbox = row.querySelector('.task-checkbox');
        var name_2 = row.querySelector('.task-name');
        if (status_1.value === 'completed') {
            checkbox.checked = true;
            checkbox.disabled = true;
            name_2.style.textDecoration = 'line-through';
        }
        else {
            checkbox.checked = false;
            checkbox.disabled = false;
            name_2.style.textDecoration = 'none';
        }
    }
});
function searchTask() {
    var searched = searchInput.value.trim().toLowerCase();
    var filteredTasks = tasks.filter(function (t) { return t.toLowerCase().includes(searched); });
    filteredTasks.push('headerrow');
    console.log(filteredTasks);
    var rows = taskTable.querySelectorAll('tr');
    rows.forEach(function (row) {
        if (filteredTasks.includes(row.id.toLowerCase())) {
            row.style.display = '';
        }
        else {
            row.style.display = 'none';
        }
    });
}
searchInput.addEventListener('keyup', function () {
    searchTask();
});
function updateTaskSuggestions() {
    datalist.innerHTML = '';
    var searchTerm = searchInput.value.trim().toLowerCase();
    var matchingTasks = tasks.filter(function (task) { return task.toLowerCase().includes(searchTerm); });
    matchingTasks.forEach(function (match) {
        var option = document.createElement('option');
        option.value = match;
        datalist.appendChild(option);
    });
}
