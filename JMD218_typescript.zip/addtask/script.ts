// @ts-nocheck

const taskInput = document.getElementById('taskInput') as HTMLInputElement
const addButton = document.getElementById('addTaskButton') as HTMLButtonElement
const taskTable = document.getElementById('taskList') as HTMLTableElement
const searchInput = document.getElementById('searchInput') as HTMLInputElement;
// const searchBtn = document.getElementById('searchBtn') as HTMLButtonElement;
const datalist = document.getElementById('taskSuggestion') as HTMLDataListElement;

let tasks: string[] = [];

function addTask() {
    const taskName: string = taskInput.value.trim();
    if (taskName != '') {
        const exists = tasks.find(ts => ts === taskName);

        if (exists) {
            alert('Task already exists');
        } else {
            const tableRow = document.createElement('tr') as HTMLTableRowElement;
            tableRow.id = taskName;
            tableRow.innerHTML = `<td>
        <input type="checkbox" aria-label="checkbox" class="task-checkbox">
    </td>
    <td>
        <span class="task-name">${taskName}</span>
    </td>
    <td>
        <select class="task-status">
            <option value="to-do">To Do</option>
            <option value="in-progress">In Progress</option>
            <option value="completed">Completed</option>
        </select>
    </td>
    <td>
        <button class="delete-button" onclick="deleteRow(this)">X</button>
    </td>`;

            taskTable.appendChild(tableRow);
            taskInput.value = '';

            tasks.push(taskName);
            updateTaskSuggestions(); // Call this to update suggestions
        }
    }
}

addButton.addEventListener('click', () => {
    addTask()
});

taskInput.addEventListener('keydown', (event)=>{
    if(event.key === 'Enter'){
        addTask()
    }
})

function deleteRow(delbtn: HTMLButtonElement) {
    row = delbtn.parentElement?.parentElement
    ind = tasks.findIndex(t => t === row.id)
    if (ind != -1) {
        tasks.splice(ind, 1)
    }
    row.remove()
}

let reset;
taskTable.addEventListener('change', (event) => {
    const target = event.target as HTMLElement;
    if (target.classList.contains('task-checkbox')) {
        const checkbox = target as HTMLInputElement;
        const row = target.parentElement?.parentElement as HTMLTableRowElement;
        const taskstatus = row.querySelector('.task-status') as HTMLSelectElement;
        const name = row.querySelector('.task-name') as HTMLElement;

        if (checkbox.checked) {
            reset = taskstatus.value;
            taskstatus.value = 'completed';
            name.style.textDecoration = 'line-through';
        } else {
            taskstatus.value = reset;
            name.style.textDecoration = 'none';
        }
    }

    if (target.classList.contains('task-status')) {
        const status = target as HTMLSelectElement;
        const row = target.parentElement?.parentElement as HTMLTableRowElement;
        const checkbox = row.querySelector('.task-checkbox') as HTMLInputElement;
        const name = row.querySelector('.task-name') as HTMLElement;

        if (status.value === 'completed') {
            checkbox.checked = true;
            checkbox.disabled = true;
            name.style.textDecoration = 'line-through';
        } else {
            checkbox.checked = false;
            checkbox.disabled = false;
            name.style.textDecoration = 'none';
        }
    }
});

function searchTask() {
    const searched = searchInput.value.trim().toLowerCase();
    const filteredTasks = tasks.filter(t => t.toLowerCase().includes(searched));
    filteredTasks.push('headerrow')
    console.log(filteredTasks);

    const rows = taskTable.querySelectorAll('tr');
    rows.forEach(row => {
        if (filteredTasks.includes(row.id.toLowerCase())) {
            row.style.display = '';
        } else {
            row.style.display = 'none';
        }
    })
}

searchInput.addEventListener('keyup', ()=>{
    searchTask()
})
function updateTaskSuggestions() {
    datalist.innerHTML = '';
    const searchTerm = searchInput.value.trim().toLowerCase();
    const matchingTasks = tasks.filter(task => task.toLowerCase().includes(searchTerm));
    matchingTasks.forEach(match => {
        const option = document.createElement('option');
        option.value = match;
        datalist.appendChild(option);
    });
}


